//
//  ViewController.swift
//  Test_Cache
//
//  Created by 신동오 on 2024/03/04.
//

import UIKit

class ViewController: UIViewController {
    
    var myDic: [String: Data] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // 어떤 작업
        
    }


}

